## `PAPIRUS_V3.0.0_REFIND-THEME_256PX-96PX_2160P`
* __`Version:`__ `3.0.0`
* __`Date:`__ `11.09.2022`
* __`License:`__  [`GPL-3.0`](https://www.gnu.org/licenses/gpl-3.0.txt)
* __`Author:`__ [`DUKE93`](https://www.pling.com/u/Duke93)
* __`Comment:`__ `Papirus theme for rEFInd`

---------------------------------

* This theme is based on: "[papirus-icon-theme](https://github.com/PapirusDevelopmentTeam/papirus-icon-theme)" is licensed under [GNU General Public License v3.0](https://www.gnu.org/licenses/gpl-3.0.txt)

---------------------------------
### Changelog:
>
___`v3.0.0 (11.09.2022)`___
>
* `Added new and updated old icons to version Papirus icons 20220710 version`
* `Updated banners`
* `Added icons for RefindPlus`
* `Added version for 4K (2160p)`










